﻿using Abp.Application.Services.Dto;

namespace LAB.Admin_bots_encje.Dto
{
    public class PagedAdmin_bot_enResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

