﻿using Abp.Application.Services.Dto;

namespace LAB.Bots_encje.Dto
{
    public class PagedBot_enResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

